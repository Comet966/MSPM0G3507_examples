# FIXED

startup_mspm0g350x_ticlang.o: \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/m0p/startup_system_files/ticlang/startup_mspm0g350x_ticlang.c \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/msp.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/DeviceFamily.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/m0p/mspm0g350x.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/third_party/CMSIS/Core/Include/core_cm0plus.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_adc12.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_aes.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_comp.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_crc.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_dac12.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_dma.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_flashctl.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_gpio.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_gptimer.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_i2c.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_iomux.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_mathacl.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_mcan.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_oa.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_rtc.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_spi.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_trng.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_uart.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_vref.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_wuc.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_wwdt.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/m0p/hw_factoryregion.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/m0p/hw_cpuss.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/m0p/hw_debugss.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/m0p/hw_sysctl.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/m0p/sysctl/hw_sysctl_mspm0g1x0x_g3x0x.h
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/msp.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/DeviceFamily.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/m0p/mspm0g350x.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/third_party/CMSIS/Core/Include/core_cm0plus.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_adc12.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_aes.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_comp.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_crc.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_dac12.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_dma.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_flashctl.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_gpio.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_gptimer.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_i2c.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_iomux.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_mathacl.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_mcan.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_oa.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_rtc.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_spi.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_trng.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_uart.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_vref.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_wuc.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_wwdt.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/m0p/hw_factoryregion.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/m0p/hw_cpuss.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/m0p/hw_debugss.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/m0p/hw_sysctl.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/m0p/sysctl/hw_sysctl_mspm0g1x0x_g3x0x.h:
