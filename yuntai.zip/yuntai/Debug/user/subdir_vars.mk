################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../user/main.c 

C_DEPS += \
./user/main.d 

OBJS += \
./user/main.o 

OBJS__QUOTED += \
"user/main.o" 

C_DEPS__QUOTED += \
"user/main.d" 

C_SRCS__QUOTED += \
"../user/main.c" 


