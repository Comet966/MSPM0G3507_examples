################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Each subdirectory must supply rules for building sources it contributes
user/%.o: ../user/%.c $(GEN_OPTS) | $(GEN_FILES) $(GEN_MISC_FILES)
	@echo 'Arm Compiler - building file: "$<"'
	"/Applications/ti/ccs2100/ccs/tools/compiler/ti-cgt-armllvm_5.1.1.LTS/bin/tiarmclang" -c @"device.opt"  -march=thumbv6m -mcpu=cortex-m0plus -mfloat-abi=soft -mlittle-endian -mthumb -O2 -I"/Users/comet/workspace_ccstheia/yuntai" -I"/Users/comet/workspace_ccstheia/yuntai/Debug" -I"/Users/comet/ti/mspm0_sdk_2_10_00_04/source/third_party/CMSIS/Core/Include" -I"/Users/comet/ti/mspm0_sdk_2_10_00_04/source" -I"/Users/comet/workspace_ccstheia/yuntai/user" -I"/Users/comet/workspace_ccstheia/yuntai/HardwareDriver" -I"/Users/comet/workspace_ccstheia/yuntai/FunctionalModule" -gdwarf-3 -Wall -MMD -MP -MF"user/$(basename $(<F)).d_raw" -MT"$(@)"  $(GEN_OPTS__FLAG) -o"$@" "$<"
	@echo 'Finished building: "$<"'
	@echo ' '


