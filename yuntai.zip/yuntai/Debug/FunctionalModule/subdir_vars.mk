################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../FunctionalModule/Gimbal.c \
../FunctionalModule/Laser.c \
../FunctionalModule/Vision.c \
../FunctionalModule/oled.c 

C_DEPS += \
./FunctionalModule/Gimbal.d \
./FunctionalModule/Laser.d \
./FunctionalModule/Vision.d \
./FunctionalModule/oled.d 

OBJS += \
./FunctionalModule/Gimbal.o \
./FunctionalModule/Laser.o \
./FunctionalModule/Vision.o \
./FunctionalModule/oled.o 

OBJS__QUOTED += \
"FunctionalModule/Gimbal.o" \
"FunctionalModule/Laser.o" \
"FunctionalModule/Vision.o" \
"FunctionalModule/oled.o" 

C_DEPS__QUOTED += \
"FunctionalModule/Gimbal.d" \
"FunctionalModule/Laser.d" \
"FunctionalModule/Vision.d" \
"FunctionalModule/oled.d" 

C_SRCS__QUOTED += \
"../FunctionalModule/Gimbal.c" \
"../FunctionalModule/Laser.c" \
"../FunctionalModule/Vision.c" \
"../FunctionalModule/oled.c" 


