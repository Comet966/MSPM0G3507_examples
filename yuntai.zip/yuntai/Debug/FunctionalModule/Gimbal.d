# FIXED

FunctionalModule/Gimbal.o: ../FunctionalModule/Gimbal.c \
 ../FunctionalModule/Gimbal.h \
 /Users/comet/workspace_ccstheia/yuntai/user/datatype.h \
 /Users/comet/workspace_ccstheia/yuntai/HardwareDriver/Stepper.h \
 /Users/comet/workspace_ccstheia/yuntai/user/headfile.h \
 ti_msp_dl_config.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/msp.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/DeviceFamily.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/m0p/mspm0g350x.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/third_party/CMSIS/Core/Include/core_cm0plus.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_adc12.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_aes.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_comp.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_crc.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_dac12.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_dma.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_flashctl.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_gpio.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_gptimer.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_i2c.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_iomux.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_mathacl.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_mcan.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_oa.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_rtc.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_spi.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_trng.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_uart.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_vref.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_wuc.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_wwdt.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/m0p/hw_factoryregion.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/m0p/hw_cpuss.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/m0p/hw_debugss.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/m0p/hw_sysctl.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/m0p/sysctl/hw_sysctl_mspm0g1x0x_g3x0x.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/driverlib.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_adc12.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_common.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/m0p/dl_factoryregion.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/m0p/dl_core.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_aes.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_aesadv.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_comp.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_crc.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_crcp.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_dac12.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_dma.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_flashctl.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/m0p/dl_sysctl.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/m0p/sysctl/dl_sysctl_mspm0g1x0x_g3x0x.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_gpamp.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_gpio.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_i2c.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_i2s.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_iwdt.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_lfss.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_keystorectl.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_lcd.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_mathacl.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_mcan.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_npu.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_opa.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_rtc.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_rtc_common.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_rtc_a.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_rtc_b.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_scratchpad.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_spgss.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_spi.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_tamperio.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_timera.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_timer.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_timerb.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_timerg.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_trng.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_uart_extend.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_uart.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_uart_main.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_unicomm.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_unicommi2cc.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_unicommi2ct.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_unicommspi.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_unicommuart.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_vref.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_wwdt.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/m0p/dl_interrupt.h \
 /Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/m0p/dl_systick.h \
 /Users/comet/workspace_ccstheia/yuntai/HardwareDriver/System.h \
 /Users/comet/workspace_ccstheia/yuntai/HardwareDriver/Uart.h \
 /Users/comet/workspace_ccstheia/yuntai/FunctionalModule/Gimbal.h \
 /Users/comet/workspace_ccstheia/yuntai/FunctionalModule/Laser.h \
 /Users/comet/workspace_ccstheia/yuntai/FunctionalModule/Vision.h
../FunctionalModule/Gimbal.h:
/Users/comet/workspace_ccstheia/yuntai/user/datatype.h:
/Users/comet/workspace_ccstheia/yuntai/HardwareDriver/Stepper.h:
/Users/comet/workspace_ccstheia/yuntai/user/headfile.h:
ti_msp_dl_config.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/msp.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/DeviceFamily.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/m0p/mspm0g350x.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/third_party/CMSIS/Core/Include/core_cm0plus.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_adc12.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_aes.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_comp.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_crc.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_dac12.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_dma.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_flashctl.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_gpio.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_gptimer.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_i2c.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_iomux.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_mathacl.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_mcan.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_oa.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_rtc.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_spi.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_trng.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_uart.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_vref.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_wuc.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_wwdt.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/m0p/hw_factoryregion.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/m0p/hw_cpuss.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/m0p/hw_debugss.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/m0p/hw_sysctl.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/m0p/sysctl/hw_sysctl_mspm0g1x0x_g3x0x.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/driverlib.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_adc12.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_common.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/m0p/dl_factoryregion.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/m0p/dl_core.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_aes.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_aesadv.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_comp.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_crc.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_crcp.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_dac12.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_dma.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_flashctl.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/m0p/dl_sysctl.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/m0p/sysctl/dl_sysctl_mspm0g1x0x_g3x0x.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_gpamp.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_gpio.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_i2c.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_i2s.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_iwdt.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_lfss.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_keystorectl.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_lcd.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_mathacl.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_mcan.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_npu.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_opa.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_rtc.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_rtc_common.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_rtc_a.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_rtc_b.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_scratchpad.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_spgss.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_spi.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_tamperio.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_timera.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_timer.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_timerb.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_timerg.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_trng.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_uart_extend.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_uart.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_uart_main.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_unicomm.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_unicommi2cc.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_unicommi2ct.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_unicommspi.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_unicommuart.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_vref.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_wwdt.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/m0p/dl_interrupt.h:
/Users/comet/ti/mspm0_sdk_2_10_00_04/source/ti/driverlib/m0p/dl_systick.h:
/Users/comet/workspace_ccstheia/yuntai/HardwareDriver/System.h:
/Users/comet/workspace_ccstheia/yuntai/HardwareDriver/Uart.h:
/Users/comet/workspace_ccstheia/yuntai/FunctionalModule/Gimbal.h:
/Users/comet/workspace_ccstheia/yuntai/FunctionalModule/Laser.h:
/Users/comet/workspace_ccstheia/yuntai/FunctionalModule/Vision.h:
